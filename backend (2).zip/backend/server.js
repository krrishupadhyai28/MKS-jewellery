const express = require("express");
const { Pool } = require("pg");

const app = express();

app.use(express.json());

const connectionString =
  "postgresql://neondb_owner:npg_JxLA6iOHt4kl@ep-steep-field-ahbitz0q-pooler.c-3.us-east-1.aws.neon.tech/neondb?sslmode=require";

const db = new Pool({
  connectionString,
  ssl: {
    rejectUnauthorized: false,
  },
});

db.on("connect", () => {
  console.log("Successfully connected to your live Cloud PostgreSQL Database!");
});

db.on("error", (err) => {
  console.error("Database Error:", err.message);
});

// ===================== GET ALL PRODUCTS =====================

app.get("/api/products", async (req, res) => {
  try {
    const result = await db.query("SELECT * FROM products");
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({
      error: err.message,
    });
  }
});

// ===================== GET PRODUCT BY ID =====================

app.get("/api/products/:id", async (req, res) => {
  try {
    const { id } = req.params;

    const result = await db.query(
      "SELECT * FROM products WHERE product_id = $1",
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        message: "Product not found",
      });
    }

    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({
      error: err.message,
    });
  }
});

// ===================== SHOW ALL TABLES (DEBUG) =====================

app.get("/tables", async (req, res) => {
  try {
    const result = await db.query(`
      SELECT table_schema, table_name
      FROM information_schema.tables
      ORDER BY table_schema, table_name;
    `);

    res.json(result.rows);
  } catch (err) {
    res.status(500).json({
      error: err.message,
    });
  }
});

app.get("/test", (req, res) => {
    res.send("SERVER UPDATED");
});

app.listen(3000, () => {
  console.log("Jewelry Server running perfectly on port 3000");
});